﻿
Partial Class Login_Login
    Inherits System.Web.UI.Page

End Class
