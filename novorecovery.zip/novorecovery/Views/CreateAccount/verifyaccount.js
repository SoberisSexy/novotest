﻿<% @page language = "java" contentType = "text/html; charset=UTF-8" pageEncoding = "UTF-8" %>
< !DOCTYPE html >
    <html lang="en">
        <head>
            <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Account Verification - NovoRecovery Social</title>
                    <!-- Add any additional stylesheets or meta tags as needed -->
                </head>
                <body>

                    <header>
                        <h1>Account Verification</h1>
                    </header>

                    <div class="container">
                        <section class="verification-content">
                            <p>Please enter the verification code sent to your phone number:</p>
                            <form action="verify" method="post">
                                <input type="text" name="verificationCode" required>
                                    <button type="submit">Verify</button>
                            </form>
                        </section>
                    </div>

                    <footer>
                        <p>&copy; 2024 NovoRecovery Social. All rights reserved.</p>
                    </footer>

                </body>
            </html>
